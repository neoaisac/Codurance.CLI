﻿namespace Codurance.Shared.Contracts
{
	public interface IHandlerChain<T> : IHandler<T>
	{
	}
}