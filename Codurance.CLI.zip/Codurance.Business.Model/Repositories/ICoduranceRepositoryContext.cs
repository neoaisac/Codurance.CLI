﻿using Codurance.Shared.Contracts;

namespace Codurance.Business.Model.Repositories
{
	public interface ICoduranceRepositoryContext : IRepositoryContext
	{
	}
}